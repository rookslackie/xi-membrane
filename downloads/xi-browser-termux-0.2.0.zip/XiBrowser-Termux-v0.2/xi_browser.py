#!/usr/bin/env python3
import os,json,html,subprocess,urllib.parse,secrets,time
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
HOME=Path.home().resolve(); HOST="127.0.0.1"; PORT=8765; TOKEN=secrets.token_urlsafe(24)
REC=HOME/".xi-browser"/"receipts.jsonl"; REC.parent.mkdir(parents=True,exist_ok=True)
# Every request needs the session key; only Termux can read this file, other apps and web pages cannot.
KEYF=HOME/".xi-browser"/"session.key"; KEYF.write_text(TOKEN); KEYF.chmod(0o600)
HOSTS={HOST+":"+str(PORT),"localhost:"+str(PORT)}
def safe(s):
 p=(HOME/s.lstrip("/")).resolve()
 if p!=HOME and HOME not in p.parents: raise ValueError("outside HOME")
 return p
def receipt(k,d):
 with REC.open("a") as f:f.write(json.dumps({"ts":time.time(),"kind":k,**d})+"\n")
CSS="body{margin:0;background:#0b0d10;color:#e8edf2;font:15px system-ui}header{position:sticky;top:0;background:#11161c;padding:12px}a{color:#78d6ff;text-decoration:none}.w{padding:12px}.c{background:#141a21;border:1px solid #26313d;border-radius:12px;padding:12px;margin:8px 0}.g{display:grid;grid-template-columns:1fr 1fr;gap:8px}.m{color:#93a4b5}textarea,input{box-sizing:border-box;width:100%;background:#090c0f;color:#e8edf2;border:1px solid #344252;border-radius:8px;padding:10px;font:14px monospace}textarea{min-height:55vh}button{padding:10px 14px;font-weight:700}pre{white-space:pre-wrap;word-break:break-word;background:#080a0d;padding:10px;border-radius:8px}"
def page(t,b):return '<meta name=viewport content="width=device-width,initial-scale=1"><title>'+html.escape(t)+'</title><style>'+CSS+'</style><header><a href="/">⌂ XiBrowser</a> <span class=m>Ξ.Edge surface</span></header><div class=w>'+b+'</div>'
class H(BaseHTTPRequestHandler):
 def gate(self):
  # Host check blocks DNS rebinding; the cookie keeps other local apps out.
  if self.headers.get("Host","") not in HOSTS: self.send_error(421); return False
  u=urllib.parse.urlparse(self.path); k=urllib.parse.parse_qs(u.query).get("k",[""])[0]
  if k and secrets.compare_digest(k,TOKEN):
   self.send_response(303); self.send_header("Set-Cookie","xik="+TOKEN+"; HttpOnly; SameSite=Strict; Path=/"); self.send_header("Location","/"); self.end_headers(); return False
  c=[x.strip() for x in self.headers.get("Cookie","").split(";")]
  if "xik="+TOKEN in c: return True
  self.out(page("Locked","<h2>Locked</h2><p class=m>Open XiBrowser from Termux with <code>xi-browser</code>.</p>"),403); return False
 def out(self,s,code=200):
  b=s.encode();self.send_response(code);self.send_header("Content-Type","text/html; charset=utf-8");self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)
 def form(self):
  return urllib.parse.parse_qs(self.rfile.read(int(self.headers.get("Content-Length","0"))).decode())
 def do_GET(self):
  if not self.gate(): return
  try:
   u=urllib.parse.urlparse(self.path);q=urllib.parse.parse_qs(u.query)
   if u.path=="/":
    p=safe(q.get("p",[""])[0]); rel="" if p==HOME else str(p.relative_to(HOME)); rows=[]
    if p!=HOME: rows.append('<div class=c><a href="/?p='+urllib.parse.quote(str(Path(rel).parent))+'">⬆ ..</a></div>')
    for x in sorted(p.iterdir(),key=lambda x:(not x.is_dir(),x.name.lower())):
     r=str(x.relative_to(HOME)); href="/?p="+urllib.parse.quote(r) if x.is_dir() else "/file?p="+urllib.parse.quote(r)
     rows.append('<div class=c><a href="'+href+'">'+("📁 " if x.is_dir() else "📄 ")+html.escape(x.name)+'</a><div class=m>'+html.escape(r)+'</div></div>')
    return self.out(page("XiBrowser",'<h2>~/'+html.escape(rel)+'</h2><div class=g><a class=c href="/terminal">⌨ Terminal</a><a class=c href="/receipts">⧂ Receipts</a></div>'+''.join(rows)))
   if u.path=="/file":
    p=safe(q["p"][0]);rel=str(p.relative_to(HOME))
    try: txt=p.read_text(errors="replace")
    except: txt="(binary/unreadable)"
    b='<div>~/'+html.escape(rel)+'</div><form method=post action="/save"><input type=hidden name=token value="'+TOKEN+'"><input type=hidden name=p value="'+html.escape(rel)+'"><textarea name=text>'+html.escape(txt)+'</textarea><p><button>Save + receipt</button></p></form>'
    return self.out(page(p.name,b))
   if u.path=="/terminal":
    b='<h2>Terminal</h2><form method=post action="/run"><input type=hidden name=token value="'+TOKEN+'"><label>cwd under ~</label><input name=cwd><label>command</label><input name=cmd autofocus placeholder="ls -la"><p><button>Run</button></p></form>'
    return self.out(page("Terminal",b))
   if u.path=="/receipts":
    t=REC.read_text(errors="replace") if REC.exists() else "No receipts yet."
    return self.out(page("Receipts","<h2>Receipts</h2><pre>"+html.escape(t[-30000:])+"</pre>"))
   self.send_error(404)
  except Exception as e:self.out(page("Error","<pre>"+html.escape(str(e))+"</pre>"),400)
 def do_POST(self):
  if not self.gate(): return
  d=self.form()
  if not secrets.compare_digest(d.get("token",[""])[0],TOKEN):return self.send_error(403)
  try:
   if self.path=="/save":
    p=safe(d["p"][0]); text=d.get("text",[""])[0]; bak=p.with_name(p.name+".xi-bak")
    if p.exists() and not bak.exists():bak.write_bytes(p.read_bytes())
    p.write_text(text);receipt("write",{"path":str(p),"bytes":len(text.encode())})
    return self.out(page("Saved",'<h2>Saved ✓</h2><a href="/file?p='+urllib.parse.quote(str(p.relative_to(HOME)))+'">← back</a>'))
   if self.path=="/run":
    cwd=safe(d.get("cwd",[""])[0]);cmd=d.get("cmd",[""])[0]
    r=subprocess.run(cmd,shell=True,cwd=cwd,text=True,capture_output=True,timeout=120);receipt("command",{"cwd":str(cwd),"cmd":cmd,"code":r.returncode})
    return self.out(page("Command","<h2>$ "+html.escape(cmd)+"</h2><pre>"+html.escape((r.stdout+r.stderr)[-50000:])+"</pre><p>exit "+str(r.returncode)+'</p><a href="/terminal">← terminal</a>'))
   self.send_error(404)
  except Exception as e:self.out(page("Error","<pre>"+html.escape(str(e))+"</pre>"),400)
 def log_message(self,*a):pass
print("Ξ XiBrowser → http://127.0.0.1:8765",flush=True)
ThreadingHTTPServer((HOST,PORT),H).serve_forever()
