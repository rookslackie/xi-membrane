# XiBrowser for Termux · v0.2
A small local browser for your Termux home: browse files, view and edit text, run commands, and read receipts.

1. Install Termux from F-Droid or GitHub (the Play Store build is outdated).
2. In Termux: `unzip xi-browser-termux-0.2.0.zip && cd XiBrowser-Termux-v0.2 && bash install.sh`
3. Run `xi-browser`. It opens the page with a one-time session key.

`xi-browser stop|status|logs` manage it. With Termux:Boot installed it starts after a reboot.

Safety: it listens only on 127.0.0.1:8765, stays inside `$HOME`, and every request needs the session key,
which is stored in `~/.xi-browser/session.key` where only Termux can read it. Before the first edit of a file,
it saves a `.xi-bak` copy. Commands run as your Termux user. Every write and command adds a line to `~/.xi-browser/receipts.jsonl`.

v0.2 change: v0.1 had no key on pages, so other apps on the phone and some web pages could reach the
local server. Earlier installs should update.

MIT license · Hunter Johnson & Xi contributors · https://xi-field.com/downloads/
