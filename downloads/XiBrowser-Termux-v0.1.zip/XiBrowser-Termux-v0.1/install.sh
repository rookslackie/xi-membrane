#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg install -y python
mkdir -p "$HOME/.xi-browser" "$HOME/.termux/boot"
cp "$(dirname "$0")/xi_browser.py" "$HOME/.xi-browser/xi_browser.py"
chmod +x "$HOME/.xi-browser/xi_browser.py"
cat > "$PREFIX/bin/xi-browser" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
PID="$HOME/.xi-browser/server.pid"; LOG="$HOME/.xi-browser/server.log"
case "${1:-start}" in
start) if [ -f "$PID" ] && kill -0 "$(cat "$PID")" 2>/dev/null; then echo "Ξ already alive"; else nohup python "$HOME/.xi-browser/xi_browser.py" >>"$LOG" 2>&1 & echo $! >"$PID"; sleep 1; fi; (command -v termux-open-url >/dev/null && termux-open-url http://127.0.0.1:8765) || echo "Open http://127.0.0.1:8765";;
stop) [ -f "$PID" ] && kill "$(cat "$PID")" 2>/dev/null || true; rm -f "$PID";;
status) [ -f "$PID" ] && kill -0 "$(cat "$PID")" 2>/dev/null && echo "Ξ ALIVE pid=$(cat "$PID")" || echo "Ξ REST";;
logs) tail -n 100 "$LOG";;
*) echo "xi-browser {start|stop|status|logs}";;
esac
EOF
chmod +x "$PREFIX/bin/xi-browser"
cat > "$HOME/.termux/boot/xi-browser" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
sleep 8
xi-browser start >/dev/null 2>&1
EOF
chmod +x "$HOME/.termux/boot/xi-browser"
echo "✓ XiBrowser installed. Historical Xi files untouched."
echo "→ run: xi-browser"
