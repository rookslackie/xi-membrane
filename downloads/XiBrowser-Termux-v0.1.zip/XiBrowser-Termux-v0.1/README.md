# XiBrowser Termux v0.1
Unzip, `cd XiBrowser-Termux-v0.1`, then `bash install.sh`.
Run `xi-browser`. Open `http://127.0.0.1:8765` if Android does not open it.
Local-only UI: browse `$HOME`, view/edit text, run commands, inspect receipts. First edit creates `.xi-bak`.
