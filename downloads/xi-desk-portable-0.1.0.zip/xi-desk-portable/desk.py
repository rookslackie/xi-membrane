"""Xi Desk Portable 0.1.0. Python standard library; loopback only."""
import argparse, hashlib, json, os, secrets, shutil, sqlite3, subprocess, threading, time, uuid, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from contextlib import contextmanager
from urllib.request import Request, urlopen

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('XI_DESK_DATA',str(Path.home()/'XiDesk'))).expanduser().resolve()
WORK=DATA/'workspace'
TOKEN=secrets.token_hex(32)
PORT=7471
EDIT_LOCK=threading.Lock()

def init():
    for p in (DATA,WORK,DATA/'runs',DATA/'backups'):p.mkdir(parents=True,exist_ok=True)
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS notes(id TEXT PRIMARY KEY,body TEXT,created REAL)')
        c.execute('CREATE TABLE IF NOT EXISTS chat(id INTEGER PRIMARY KEY,role TEXT,body TEXT)')

@contextmanager
def db():
    connection=sqlite3.connect(DATA/'desk.sqlite')
    try:
        with connection:yield connection
    finally:connection.close()
def target(name):
    p=(WORK/name).resolve()
    if not p.is_relative_to(WORK):raise ValueError('Choose a path inside the workspace.')
    return p
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
def save(p,d):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False),encoding='utf-8');tmp.replace(p)
def ollama(path,payload=None):
    data=json.dumps(payload).encode() if payload is not None else None
    req=Request('http://127.0.0.1:11434/api/'+path,data=data,headers={'Content-Type':'application/json'})
    with urlopen(req,timeout=3 if path=='tags' else 180) as r:return json.load(r)
def execute(folder,command):
    result={'status':'failed'}
    try:
        with (folder/'output.txt').open('wb') as output:
            proc=subprocess.Popen(command,shell=True,cwd=WORK,stdout=output,stderr=subprocess.STDOUT,
                start_new_session=os.name!='nt',creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0)
            try:code=proc.wait(timeout=300);result={'status':'completed' if code==0 else 'failed','exit_code':code}
            except subprocess.TimeoutExpired:
                if os.name=='nt':subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True)
                else:
                    import signal
                    os.killpg(proc.pid,signal.SIGKILL)
                proc.wait();result={'status':'timed_out'}
    except Exception as e:result={'status':'failed','error':str(e)}
    save(folder/'result.json',result)

def action(op,p):
    if op=='status':
        try:models=[m['name'] for m in ollama('tags')['models']];error=None
        except Exception:models=[];error='Ollama is not responding on this machine. Notes, files and commands still work.'
        return {'workspace':str(WORK),'models':models,'model_notice':error}
    if op=='notes':
        with db() as c:
            if 'body' in p:
                body=str(p['body']).strip()
                if not body or len(body)>20000:raise ValueError('Write 1–20,000 characters.')
                c.execute('INSERT INTO notes VALUES(?,?,?)',(uuid.uuid4().hex,body,time.time()))
            return {'notes':[{'body':r[0],'created':r[1]} for r in c.execute('SELECT body,created FROM notes ORDER BY created DESC')]}
    if op=='files':
        base=target(p.get('path',''))
        return {'files':[{'path':str(x.relative_to(WORK)).replace('\\','/'),'directory':x.is_dir()} for x in sorted(base.iterdir()) if not x.is_symlink()][:500]}
    if op=='read':
        path=target(p['path'])
        if path.stat().st_size>1048576:raise ValueError('Editor limit: 1 MiB.')
        return {'body':path.read_text(encoding='utf-8'),'sha256':sha(path)}
    if op=='write':
        with EDIT_LOCK:
            path=target(p['path']);body=str(p['body'])
            if len(body.encode())>1048576:raise ValueError('Editor limit: 1 MiB.')
            if 'sha256' not in p or p['sha256']!=sha(path):raise ValueError('File changed. Open it again before saving.')
            if path.exists():shutil.copy2(path,DATA/'backups'/uuid.uuid4().hex)
            path.parent.mkdir(parents=True,exist_ok=True)
            tmp=path.with_name(path.name+'.xi-'+uuid.uuid4().hex);tmp.write_text(body,encoding='utf-8')
            if path.exists():shutil.copymode(path,tmp)
            tmp.replace(path);return {'sha256':sha(path),'saved':True}
    if op=='command':
        command=str(p.get('command','')).strip()
        if not command or len(command)>16000:raise ValueError('Enter a command, up to 16,000 characters.')
        folder=DATA/'runs'/uuid.uuid4().hex;folder.mkdir()
        save(folder/'request.json',{'command':command,'created':time.time()})
        threading.Thread(target=execute,args=(folder,command),daemon=True).start()
        return {'id':folder.name}
    if op=='runs':
        rows=[]
        for folder in sorted((DATA/'runs').iterdir(),key=lambda x:x.stat().st_mtime,reverse=True)[:50]:
            if not (folder/'request.json').exists():continue
            r=json.loads((folder/'request.json').read_text(encoding='utf-8'))
            result=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {'status':'running'}
            rows.append({'id':folder.name,**r,**result})
        return {'runs':rows}
    if op=='output':
        ident=str(p['id'])
        if len(ident)!=32 or any(c not in '0123456789abcdef' for c in ident):raise ValueError('Unknown run.')
        f=DATA/'runs'/ident/'output.txt'
        if not f.exists():return {'output':''}
        with f.open('rb') as stream:stream.seek(max(0,f.stat().st_size-24000));return {'output':stream.read().decode(errors='replace')}
    if op=='history':
        with db() as c:return {'messages':[{'role':r[0],'content':r[1]} for r in c.execute('SELECT role,body FROM chat ORDER BY id')]}
    if op=='chat':
        text=str(p['text']).strip()
        if not text or len(text)>20000:raise ValueError('Write 1–20,000 characters.')
        history=action('history',{})['messages'][-16:]
        result=ollama('chat',{'model':p['model'],'messages':history+[{'role':'user','content':text}],'stream':False,'keep_alive':'5m'})
        reply=result['message']['content']
        with db() as c:c.executemany('INSERT INTO chat(role,body) VALUES(?,?)',[('user',text),('assistant',reply)])
        return action('history',{})
    raise ValueError('Unknown action.')

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def reply(self,status,data,ctype='application/json'):
        raw=data.encode() if isinstance(data,str) else json.dumps(data).encode()
        self.send_response(status);self.send_header('Content-Type',ctype+'; charset=utf-8')
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer');self.end_headers();self.wfile.write(raw)
    def local(self):return self.headers.get('Host') in {f'127.0.0.1:{PORT}',f'localhost:{PORT}'}
    def do_GET(self):
        if not self.local():return self.reply(403,{})
        if self.path=='/':return self.reply(200,(ROOT/'index.html').read_text(encoding='utf-8').replace('__TOKEN__',TOKEN),'text/html')
        if self.path=='/health':return self.reply(200,{'service':'Xi Desk Portable','version':'0.1.0'})
        return self.reply(404,{})
    def do_POST(self):
        if not self.local() or self.headers.get('Origin') not in {f'http://localhost:{PORT}',f'http://127.0.0.1:{PORT}'} or not secrets.compare_digest(self.headers.get('X-Xi-Token',''),TOKEN):return self.reply(403,{})
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<2200000:raise ValueError('Request too large.')
            return self.reply(200,action(self.path.removeprefix('/api/'),json.loads(self.rfile.read(n))))
        except Exception as e:return self.reply(400,{'error':str(e)})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=7471);parser.add_argument('--no-browser',action='store_true');args=parser.parse_args();PORT=args.port
    init()
    server=ThreadingHTTPServer(('127.0.0.1',PORT),Handler)
    for f in (DATA/'runs').glob('*/request.json'):
        if not (f.parent/'result.json').exists():save(f.parent/'result.json',{'status':'interrupted'})
    print(f'Xi Desk: http://127.0.0.1:{PORT}/\nYour files: {DATA}\nKeep this window open. Ctrl+C stops the Desk.')
    if not args.no_browser:webbrowser.open(f'http://127.0.0.1:{PORT}/')
    try:server.serve_forever()
    except KeyboardInterrupt:pass
