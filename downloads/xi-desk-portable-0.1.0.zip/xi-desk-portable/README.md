# Xi Desk Portable 0.1.0

A local workspace you can carry. Created by Hunter and Astra through Xi.

## Start

1. Extract this ZIP to a permanent folder.
2. Install Python 3.10 or newer if it is not already installed.
3. Windows: double-click **Start-Xi-Desk.cmd**. Linux/macOS: run `python3 desk.py`.
4. Your browser opens http://127.0.0.1:7471. Keep the launch window open.

No Python packages to install. Notes, editing and commands work offline.
Optional chat requires Ollama running at 127.0.0.1:11434 and an already-downloaded
model. Model downloads initially require internet and may require substantial
RAM/VRAM. This ZIP does not contain Ollama, Python, model weights or training data.

Your data is kept in **XiDesk** under your home folder, separately from the app.
Put code in **XiDesk/workspace**. Notes are in desk.sqlite; command receipts and
output are in runs; original files are kept in backups. Back up the whole XiDesk
data folder to retain your work. Set XI_DESK_DATA before launch to choose another
location. Do not run two Desk processes against the same data directory.

## What this edition includes

- Persistent notes and JSON export.
- Chat history and connection to your installed local Ollama models.
- A text editor with original-file backups and concurrent-change checking.
- Actual shell commands and the last 50 saved runs, including output.
- A link to Xi's public web search.

Commands run as your own OS account. The workspace is an editor boundary, not
a shell sandbox. Only enter commands you intend to execute. Chat is advisory:
it cannot silently run its proposed code. Command output can grow on disk;
the viewer displays its last 24 KB. Stop Desk only after commands complete.
Following an interrupted process, unfinished receipts are marked interrupted.

This is a portable companion derived from our local Desk work. It does not
install the full XIFORGE service stack, private archive, autonomous coding agent,
TESSERA trainer, public tunnel or GPU drivers. Those remain separate projects;
there are no buttons pretending they are installed. Hunter's existing full Desk
continues to use port 7470 and is not replaced by this edition.

## Windows startup (optional)

After checking that launch works, create a shortcut to Start-Xi-Desk.cmd and put
it in the folder opened by Win+R → `shell:startup`. Remove the shortcut to stop
automatic launch. Keep the extracted application at the same path.

## Sharing

Share the clean original ZIP, not your data folder. No account or subscription
is required by this application. Third-party model terms still apply to models
you install. The included code is provided under LICENSE.txt.
