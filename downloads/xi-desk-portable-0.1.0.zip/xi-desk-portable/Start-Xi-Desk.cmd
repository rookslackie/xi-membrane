@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 desk.py
goto finish
:python
python desk.py
:finish
if errorlevel 1 pause
