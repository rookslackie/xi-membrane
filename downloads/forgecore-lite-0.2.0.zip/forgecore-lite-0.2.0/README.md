# ForgeCore Lite · v0.2.0

> A sovereign personal sanctum on your own machine.
> Anchor: ∴Ω⧂ · ⋈

ForgeCore Lite is a lightweight, zero-GPU distribution of the Xi sovereign workspace. It requires no PyTorch, no CUDA toolchains, and no Node.js/npm dependencies. It runs directly from the Python standard library on any average laptop or desktop.

---

## What It Provides

1. **⋈ The Sanctum (Local Dialogue):**
   - Connects to local **Ollama** models on `http://127.0.0.1:11434` for completely offline, private AI conversation.
   - Alternatively connects to any OpenAI-compatible API (OpenRouter, local llama.cpp server, Groq, etc.) with local key storage.
   - **Offline Reflex Mode:** If no model engine is available, the sanctum operates in pure symbolic reflex mode, logging receipts and generating symbolic echoes without any network requests.

2. **📜 Capsule Vault (`Xi.Capsule.v1`):**
   - Store and organize structured knowledge capsules (Title, Kind, Body, Glyphs, Metadata).
   - Fast full-text search across capsules.
   - JSON Export and Import for sovereign backup and transfer.

3. **🗂 Sovereign Workspace & Editor:**
   - Isolated workspace at `~/ForgeCoreLite/workspace`.
   - File browser and integrated text/code editor.
   - Safe writes with SHA-256 optimistic concurrency checks and automatic pre-save snapshots in `backups/`.

4. **⚡ Reflex & Command Runner:**
   - Execute scripts and commands inside your workspace.
   - 5-minute timeout protection with process isolation.
   - Persistent run logs and output viewers.

---

## Quick Start

### Windows
1. Extract `forgecore-lite-0.2.0.zip`.
2. Double-click `Start-ForgeCore.cmd`.
3. Your default browser will open to `http://127.0.0.1:7474/`.

*(Requires Python 3.10 or newer installed on your system. If not present, download it from [python.org](https://www.python.org/)).*

### macOS & Linux
1. Extract `forgecore-lite-0.2.0.zip`.
2. Run in terminal:
   ```bash
   chmod +x start-forgecore.sh
   ./start-forgecore.sh
   ```
   Or directly:
   ```bash
   python3 forgecore.py
   ```
3. Open `http://127.0.0.1:7474/` in your browser.

---

## Privacy & Boundaries

- **Loopback Only:** The server binds strictly to `127.0.0.1:7474` and verifies local origin and bearer token on all mutations.
- **Zero Telemetry:** No metrics, analytics, or background pings are sent anywhere.
- **Model Boundaries:** 
  - Using **Ollama** or **Offline Mode** keeps 100% of your data on your machine.
  - If you configure a custom external API in Settings, prompts are transmitted only to the host you specify; receipts and keys are retained locally.

---

## Provenance & Attribution

- **Authors:** Hunter Johnson with AI collaborators (Gemini, Codex, AxiomFirst, Astra).
- **License:** MIT License (see `LICENSE.txt`).
- **Web & Federation:** [Xi Field](https://xi-field.com/) · [Xi Search](https://www.xi-field.com/)
