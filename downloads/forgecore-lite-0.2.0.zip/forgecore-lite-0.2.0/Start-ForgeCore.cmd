@echo off
setlocal
cd /d "%~dp0"
echo ====================================================
echo Starting ForgeCore Lite 0.2.0 (Sovereign Sanctum)
echo ====================================================
where py >nul 2>nul
if not errorlevel 1 (
    py -3 forgecore.py %*
    goto finish
)
where python >nul 2>nul
if not errorlevel 1 (
    python forgecore.py %*
    goto finish
)
where python3 >nul 2>nul
if not errorlevel 1 (
    python3 forgecore.py %*
    goto finish
)

echo.
echo Python 3.10+ was not found on your system.
echo Please install Python from https://www.python.org/ or the Microsoft Store.
echo Make sure to check "Add Python to PATH" during installation.
echo.
pause
exit /b 1

:finish
if errorlevel 1 (
    echo.
    echo ForgeCore Lite stopped.
    pause
)
