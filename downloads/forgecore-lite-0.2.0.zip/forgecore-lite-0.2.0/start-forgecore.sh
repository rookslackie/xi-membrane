#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "===================================================="
echo "Starting ForgeCore Lite 0.2.0 (Sovereign Sanctum)"
echo "===================================================="

if command -v python3 >/dev/null 2>&1; then
    exec python3 forgecore.py "$@"
elif command -v python >/dev/null 2>&1; then
    exec python forgecore.py "$@"
else
    echo "Python 3 is required. Please install python3 to run ForgeCore Lite."
    exit 1
fi
