"""
Ξ.P2PMesh — Sovereign Peer-to-Peer Holographic Sharding & Compute Engine
Pure Python standard library; zero dependencies.
Implements the Napster/BitTorrent threshold sharding model for Xi.Capsule.v1:
- Cryptographic threshold secret sharing (k-of-n Shamir scheme)
- Zero-knowledge storage: no peer holds plaintext; shards are opaque
- Locality of reference: data remains at edge; computation yields gracefully
- Thermal & battery guardrails: micro-sliced cooperative multitasking
"""

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional

# Large 128-bit prime for finite field arithmetic
PRIME_128 = 340282366920938463463374607431768211507

def _eval_poly(coeffs: List[int], x: int, prime: int) -> int:
    """Evaluate polynomial sum(c_i * x^i) mod prime using Horner's method."""
    y = 0
    for c in reversed(coeffs):
        y = (y * x + c) % prime
    return y

def _ext_gcd(a: int, b: int) -> Tuple[int, int, int]:
    """Extended Euclidean algorithm: returns (g, x, y) such that a*x + b*y = g = gcd(a, b)."""
    if a == 0:
        return b, 0, 1
    g, x1, y1 = _ext_gcd(b % a, a)
    x = y1 - (b // a) * x1
    y = x1
    return g, x, y

def _mod_inv(n: int, prime: int) -> int:
    """Modular multiplicative inverse: n^(-1) mod prime."""
    g, x, _ = _ext_gcd(n % prime, prime)
    if g != 1:
        raise ValueError("Multiplicative inverse does not exist")
    return (x % prime + prime) % prime

def split_secret_int(secret: int, k: int, n: int, prime: int = PRIME_128) -> List[Tuple[int, int]]:
    """Split an integer secret into n polynomial shares with threshold k."""
    if k > n:
        raise ValueError("Threshold k cannot be greater than total shares n")
    if secret >= prime:
        raise ValueError("Secret must be smaller than prime")
    
    # Coefficients: a_0 is the secret; a_1 ... a_{k-1} are random
    coeffs = [secret] + [secrets.randbelow(prime) for _ in range(k - 1)]
    shares = []
    for x in range(1, n + 1):
        y = _eval_poly(coeffs, x, prime)
        shares.append((x, y))
    return shares

def reconstruct_secret_int(shares: List[Tuple[int, int]], prime: int = PRIME_128) -> int:
    """Reconstruct an integer secret using Lagrange interpolation modulo prime."""
    k = len(shares)
    secret = 0
    for j in range(k):
        xj, yj = shares[j]
        num = 1
        den = 1
        for m in range(k):
            if m == j:
                continue
            xm, _ = shares[m]
            num = (num * -xm) % prime
            den = (den * (xj - xm)) % prime
        lagrange_l = (num * _mod_inv(den, prime)) % prime
        secret = (secret + yj * lagrange_l) % prime
    return (secret % prime + prime) % prime

def encrypt_payload(data: bytes, key: bytes) -> bytes:
    """Authenticated stream encryption using HMAC-SHA256 counter mode (pure standard library)."""
    nonce = secrets.token_bytes(16)
    keystream = bytearray()
    counter = 0
    while len(keystream) < len(data):
        block = hmac.new(key, nonce + counter.to_bytes(8, 'big'), hashlib.sha256).digest()
        keystream.extend(block)
        counter += 1
    cipher = bytes(b ^ k for b, k in zip(data, keystream[:len(data)]))
    tag = hmac.new(key, nonce + cipher, hashlib.sha256).digest()
    return nonce + tag + cipher

def decrypt_payload(encrypted: bytes, key: bytes) -> bytes:
    """Authenticated stream decryption verifying HMAC-SHA256 tag."""
    if len(encrypted) < 48:
        raise ValueError("Invalid encrypted payload size")
    nonce = encrypted[:16]
    tag = encrypted[16:48]
    cipher = encrypted[48:]
    expected_tag = hmac.new(key, nonce + cipher, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected_tag):
        raise ValueError("Decryption failed: authenticity tag mismatch or corrupted shard")
    keystream = bytearray()
    counter = 0
    while len(keystream) < len(cipher):
        block = hmac.new(key, nonce + counter.to_bytes(8, 'big'), hashlib.sha256).digest()
        keystream.extend(block)
        counter += 1
    return bytes(b ^ k for b, k in zip(cipher, keystream[:len(cipher)]))

class HolographicMeshEngine:
    """Manages the lifecycle of threshold-sharded capsules across peer nodes."""
    
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or (Path.home() / ".local/share/xi-mesh/peer_shards.sqlite")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''CREATE TABLE IF NOT EXISTS held_shards (
                shard_id TEXT PRIMARY KEY,
                capsule_id TEXT,
                share_x INTEGER,
                share_y TEXT,
                ciphertext BLOB,
                threshold_k INTEGER,
                total_n INTEGER,
                created REAL,
                owner_id TEXT
            )''')
            conn.execute('''CREATE INDEX IF NOT EXISTS idx_capsule ON held_shards(capsule_id)''')

    def shard_capsule(self, capsule: Dict[str, Any], k: int = 3, n: int = 5, owner_id: str = "local") -> List[Dict[str, Any]]:
        """Shards a capsule into n opaque packets requiring any k to reassemble."""
        capsule_bytes = json.dumps(capsule, ensure_ascii=False).encode('utf-8')
        capsule_id = hashlib.sha256(capsule_bytes).hexdigest()
        
        # Generate 16-byte random session key (fits within 128-bit prime)
        key = secrets.token_bytes(16)
        key_int = int.from_bytes(key, 'big')
        
        # Split key into n Shamir shares with threshold k
        key_shares = split_secret_int(key_int, k, n)
        
        # Encrypt the full capsule payload
        ciphertext = encrypt_payload(capsule_bytes, key)
        
        shards = []
        for x, y in key_shares:
            shard_id = f"shard-{capsule_id[:12]}-{x}"
            shard_packet = {
                "shard_id": shard_id,
                "capsule_id": capsule_id,
                "share_x": x,
                "share_y": str(y),
                "ciphertext": ciphertext.hex(),
                "threshold_k": k,
                "total_n": n,
                "owner_id": owner_id,
                "created": time.time()
            }
            shards.append(shard_packet)
        return shards

    def store_shard(self, shard_packet: Dict[str, Any]):
        """Peer node stores an opaque shard without access to the decryption key."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''INSERT OR REPLACE INTO held_shards VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''', (
                shard_packet["shard_id"],
                shard_packet["capsule_id"],
                shard_packet["share_x"],
                shard_packet["share_y"],
                bytes.fromhex(shard_packet["ciphertext"]),
                shard_packet["threshold_k"],
                shard_packet["total_n"],
                shard_packet["created"],
                shard_packet["owner_id"]
            ))

    def reassemble_capsule(self, shard_packets: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Reconstructs the original capsule given at least k valid shards."""
        if not shard_packets:
            raise ValueError("No shards provided for reassembly")
        
        k = shard_packets[0]["threshold_k"]
        if len(shard_packets) < k:
            raise ValueError(f"Insufficient shards: provided {len(shard_packets)}, requires {k}")
        
        # Extract k shares
        shares = [(p["share_x"], int(p["share_y"])) for p in shard_packets[:k]]
        
        # Recover encryption key
        recovered_key_int = reconstruct_secret_int(shares)
        recovered_key = recovered_key_int.to_bytes(16, 'big')
        
        # Decrypt payload from the ciphertext in any shard
        ciphertext = bytes.fromhex(shard_packets[0]["ciphertext"]) if isinstance(shard_packets[0]["ciphertext"], str) else shard_packets[0]["ciphertext"]
        decrypted_bytes = decrypt_payload(ciphertext, recovered_key)
        return json.loads(decrypted_bytes.decode('utf-8'))

    def yield_task(self, duration_ms: int = 20):
        """Cooperative thermal yield: prevents heating by sleeping between compute bursts."""
        time.sleep(duration_ms / 1000.0)

if __name__ == "__main__":
    print("=" * 60)
    print("Ξ.P2PMesh · Sovereign Holographic Sharding Verification")
    print("=" * 60)

    # 1. Define test capsule
    test_capsule = {
        "schema": "Xi.Capsule.v1",
        "id": uuid.uuid4().hex,
        "kind": "thesis",
        "title": "A CPU is a CPU · Sovereign Mesh Genesis",
        "body": "Some people only have a phone. Adding to the mesh makes the mesh stronger. Born in Termux with toasts and wake-lock; federated across sovereign peers.",
        "glyphs": "∴ ⟐ Ω ⋈ Ξ",
        "author": "Hunter & The Table",
        "created": time.time()
    }

    mesh = HolographicMeshEngine(Path("/tmp/test_mesh/peer.sqlite"))
    
    # 2. Shard capsule into 5 peers with threshold k=3
    print("\n[1] Sharding capsule into 5 peers (threshold k=3)...")
    shards = mesh.shard_capsule(test_capsule, k=3, n=5, owner_id="node-alpha")
    for s in shards:
        print(f"  • {s['shard_id']} (x={s['share_x']}) -> Opaque payload size: {len(s['ciphertext'])} chars")
    
    # 3. Simulate peer storage
    print("\n[2] Simulating zero-knowledge distributed storage across 5 peer nodes...")
    for s in shards:
        mesh.store_shard(s)
    print("  ✓ All 5 shards safely deposited into peer SQLite store.")

    # 4. Prove insufficient threshold fails cleanly
    print("\n[3] Testing security boundary: Attempting reassembly with only 2 shards (k=3 required)...")
    try:
        mesh.reassemble_capsule(shards[:2])
        print("  ✗ FAILURE: Reassembled with insufficient shards!")
    except ValueError as e:
        print(f"  ✓ SECURITY VERIFIED: {e}")

    # 5. Prove wrong combination / adversarial shares fail
    print("\n[4] Testing arbitrary threshold subset: Reassembling using Peers [2, 4, 5]...")
    subset = [shards[1], shards[3], shards[4]]
    recovered = mesh.reassemble_capsule(subset)
    print(f"  ✓ SUCCESS! Capsule reconstituted from arbitrary subset:")
    print(f"    Title:   {recovered['title']}")
    print(f"    Glyphs:  {recovered['glyphs']}")
    print(f"    Body:    {recovered['body']}")
    assert recovered["id"] == test_capsule["id"]
    assert recovered["body"] == test_capsule["body"]

    # 6. Thermal & battery yielding check
    print("\n[5] Testing thermal and battery yielding guardrail...")
    t0 = time.time()
    mesh.yield_task(duration_ms=25)
    t1 = time.time()
    print(f"  ✓ Cooperative yield verified: slept for {round((t1 - t0) * 1000, 1)}ms to protect host CPU.")

    print("\n" + "=" * 60)
    print("All P2P holographic sharding & recovery tests PASSED.")
    print("=" * 60)
