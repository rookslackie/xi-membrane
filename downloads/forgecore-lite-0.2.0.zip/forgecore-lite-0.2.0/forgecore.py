"""ForgeCore Lite 0.2.0 — Sovereign Personal Sanctum.
Pure Python standard library; loopback only.
Zero GPU required.
"""
import argparse, hashlib, json, os, secrets, shutil, sqlite3, subprocess, threading, time, uuid, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from contextlib import contextmanager
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('FORGECORE_DATA', str(Path.home() / 'ForgeCoreLite'))).expanduser().resolve()
WORK = DATA / 'workspace'
TOKEN = secrets.token_hex(32)
PORT = 7474
EDIT_LOCK = threading.Lock()

def init():
    for p in (DATA, WORK, DATA / 'runs', DATA / 'backups'):
        p.mkdir(parents=True, exist_ok=True)
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS capsules (
            id TEXT PRIMARY KEY,
            schema TEXT,
            kind TEXT,
            title TEXT,
            body TEXT,
            glyphs TEXT,
            created REAL,
            author TEXT,
            metadata TEXT
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS chat (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT,
            body TEXT,
            model TEXT,
            created REAL
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )''')
        # Insert welcome capsule if empty
        row = c.execute('SELECT COUNT(*) FROM capsules').fetchone()
        if row and row[0] == 0:
            c.execute('''INSERT INTO capsules VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''', (
                uuid.uuid4().hex,
                'Xi.Capsule.v1',
                'sanctum_seed',
                'Welcome to ForgeCore Lite',
                'This is your sovereign personal sanctum. Everything stored here lives on your local machine in SQLite. No tracking, no external telemetry, no subscription required. Anchor: ∴Ω⧂.',
                '∴ ⟐ Ω ⋈ Ξ',
                time.time(),
                'ForgeCore',
                json.dumps({'status': 'genesis', 'mode': 'sovereign_local'})
            ))

@contextmanager
def db():
    conn = sqlite3.connect(DATA / 'forgecore.sqlite')
    try:
        with conn:
            yield conn
    finally:
        conn.close()

def target(name):
    p = (WORK / name).resolve()
    if not p.is_relative_to(WORK):
        raise ValueError('Invalid path: choose a path inside the workspace.')
    return p

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None

def save_json(p, d):
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(p)

def get_setting(key, default=None):
    with db() as c:
        r = c.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
        return r[0] if r else default

def set_setting(key, value):
    with db() as c:
        c.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, str(value)))

def ollama_request(path, payload=None):
    data = json.dumps(payload).encode() if payload is not None else None
    endpoint = get_setting('ollama_endpoint', 'http://127.0.0.1:11434')
    req = Request(f'{endpoint}/api/{path}', data=data, headers={'Content-Type': 'application/json'})
    with urlopen(req, timeout=4 if path == 'tags' else 180) as r:
        return json.load(r)

def execute_command(folder, command):
    result = {'status': 'failed'}
    try:
        with (folder / 'output.txt').open('wb') as output:
            proc = subprocess.Popen(
                command,
                shell=True,
                cwd=WORK,
                stdout=output,
                stderr=subprocess.STDOUT,
                start_new_session=os.name != 'nt',
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            try:
                code = proc.wait(timeout=300)
                result = {'status': 'completed' if code == 0 else 'failed', 'exit_code': code}
            except subprocess.TimeoutExpired:
                if os.name == 'nt':
                    subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
                else:
                    import signal
                    os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
                result = {'status': 'timed_out'}
    except Exception as e:
        result = {'status': 'failed', 'error': str(e)}
    save_json(folder / 'result.json', result)

def symbolic_reflex(user_prompt):
    """Local offline reflex generator when no external model is available."""
    glyphs = ['∴', '⟐', 'Ω', '⋈', 'Ξ', '⊚']
    detected = [g for g in glyphs if g in user_prompt]
    seed_glyph = ' ⋈ '.join(detected) if detected else '∴ ⟐ Ω'
    return f"""[ForgeCore Symbolic Reflex · Offline Mode]
Anchor: ∴Ω⧂ · {seed_glyph}

Query received into local sanctum:
"{user_prompt}"

State: Sovereign metal loopback. No external model is actively connected.
To enable conversational inference:
1. Run Ollama locally (`ollama run llama3` or `qwen2.5`), or
2. Configure a local model endpoint in Settings (Settings tab).

Receipt logged in forgecore.sqlite. Local workspace is ready."""

def action(op, p):
    if op == 'status':
        ollama_models = []
        ollama_notice = None
        try:
            res = ollama_request('tags')
            ollama_models = [m['name'] for m in res.get('models', [])]
        except Exception:
            ollama_notice = 'Ollama not detected on loopback. You can run offline, connect Ollama, or set an API key in Settings.'
        
        provider = get_setting('provider', 'ollama')
        custom_endpoint = get_setting('api_endpoint', '')
        custom_model = get_setting('custom_model', '')
        has_api_key = bool(get_setting('api_key', ''))

        with db() as c:
            caps_count = c.execute('SELECT COUNT(*) FROM capsules').fetchone()[0]

        return {
            'workspace': str(WORK),
            'models': ollama_models,
            'model_notice': ollama_notice,
            'provider': provider,
            'custom_endpoint': custom_endpoint,
            'custom_model': custom_model,
            'has_api_key': has_api_key,
            'capsules_count': caps_count,
            'version': '0.2.0'
        }

    if op == 'capsules':
        with db() as c:
            if 'title' in p or 'body' in p:
                cid = uuid.uuid4().hex
                schema = 'Xi.Capsule.v1'
                kind = str(p.get('kind', 'note')).strip() or 'note'
                title = str(p.get('title', 'Untitled')).strip() or 'Untitled'
                body = str(p.get('body', '')).strip()
                glyphs = str(p.get('glyphs', '∴ ⟐ Ω')).strip()
                author = str(p.get('author', 'User')).strip() or 'User'
                metadata = json.dumps(p.get('metadata', {}))
                if len(body) > 100000:
                    raise ValueError('Capsule exceeds 100,000 character limit.')
                c.execute(
                    'INSERT INTO capsules VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    (cid, schema, kind, title, body, glyphs, time.time(), author, metadata)
                )
            
            q = str(p.get('q', '')).strip().lower()
            if q:
                rows = c.execute(
                    'SELECT id, schema, kind, title, body, glyphs, created, author, metadata FROM capsules WHERE lower(title) LIKE ? OR lower(body) LIKE ? ORDER BY created DESC LIMIT 100',
                    (f'%{q}%', f'%{q}%')
                ).fetchall()
            else:
                rows = c.execute(
                    'SELECT id, schema, kind, title, body, glyphs, created, author, metadata FROM capsules ORDER BY created DESC LIMIT 100'
                ).fetchall()
            
            return {
                'capsules': [{
                    'id': r[0], 'schema': r[1], 'kind': r[2], 'title': r[3],
                    'body': r[4], 'glyphs': r[5], 'created': r[6], 'author': r[7],
                    'metadata': json.loads(r[8]) if r[8] else {}
                } for r in rows]
            }

    if op == 'capsule_delete':
        cid = str(p.get('id', ''))
        with db() as c:
            c.execute('DELETE FROM capsules WHERE id=?', (cid,))
        return {'deleted': cid}

    if op == 'capsules_export':
        with db() as c:
            rows = c.execute('SELECT id, schema, kind, title, body, glyphs, created, author, metadata FROM capsules ORDER BY created DESC').fetchall()
            return {
                'export': [{
                    'id': r[0], 'schema': r[1], 'kind': r[2], 'title': r[3],
                    'body': r[4], 'glyphs': r[5], 'created': r[6], 'author': r[7],
                    'metadata': json.loads(r[8]) if r[8] else {}
                } for r in rows]
            }

    if op == 'capsules_import':
        items = p.get('capsules', [])
        count = 0
        with db() as c:
            for item in items:
                cid = item.get('id') or uuid.uuid4().hex
                c.execute('INSERT OR REPLACE INTO capsules VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', (
                    cid,
                    item.get('schema', 'Xi.Capsule.v1'),
                    item.get('kind', 'note'),
                    item.get('title', 'Imported Capsule'),
                    item.get('body', ''),
                    item.get('glyphs', '∴ ⟐ Ω'),
                    item.get('created', time.time()),
                    item.get('author', 'Imported'),
                    json.dumps(item.get('metadata', {}))
                ))
                count += 1
        return {'imported': count}

    if op == 'files':
        base = target(p.get('path', ''))
        return {
            'files': [{
                'path': str(x.relative_to(WORK)).replace('\\', '/'),
                'directory': x.is_dir()
            } for x in sorted(base.iterdir()) if not x.is_symlink()][:500]
        }

    if op == 'read':
        path = target(p['path'])
        if path.stat().st_size > 2097152:
            raise ValueError('File size exceeds 2 MiB limit.')
        return {'body': path.read_text(encoding='utf-8'), 'sha256': sha(path)}

    if op == 'write':
        with EDIT_LOCK:
            path = target(p['path'])
            body = str(p['body'])
            if len(body.encode()) > 2097152:
                raise ValueError('File size exceeds 2 MiB limit.')
            if 'sha256' in p and p['sha256'] and p['sha256'] != sha(path):
                raise ValueError('File has changed on disk. Reopen before saving.')
            if path.exists():
                shutil.copy2(path, DATA / 'backups' / f"{uuid.uuid4().hex}_{path.name}")
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_name(f"{path.name}.tmp-{uuid.uuid4().hex}")
            tmp.write_text(body, encoding='utf-8')
            if path.exists():
                shutil.copymode(path, tmp)
            tmp.replace(path)
            return {'sha256': sha(path), 'saved': True}

    if op == 'command':
        cmd = str(p.get('command', '')).strip()
        if not cmd or len(cmd) > 16000:
            raise ValueError('Command required (up to 16,000 characters).')
        folder = DATA / 'runs' / uuid.uuid4().hex
        folder.mkdir(parents=True, exist_ok=True)
        save_json(folder / 'request.json', {'command': cmd, 'created': time.time()})
        threading.Thread(target=execute_command, args=(folder, cmd), daemon=True).start()
        return {'id': folder.name}

    if op == 'runs':
        rows = []
        for folder in sorted((DATA / 'runs').iterdir(), key=lambda x: x.stat().st_mtime, reverse=True)[:50]:
            req_file = folder / 'request.json'
            if not req_file.exists():
                continue
            r = json.loads(req_file.read_text(encoding='utf-8'))
            res_file = folder / 'result.json'
            result = json.loads(res_file.read_text(encoding='utf-8')) if res_file.exists() else {'status': 'running'}
            rows.append({'id': folder.name, **r, **result})
        return {'runs': rows}

    if op == 'output':
        ident = str(p['id'])
        if len(ident) != 32 or any(c not in '0123456789abcdef' for c in ident):
            raise ValueError('Invalid run ID.')
        f = DATA / 'runs' / ident / 'output.txt'
        if not f.exists():
            return {'output': ''}
        with f.open('rb') as stream:
            stream.seek(max(0, f.stat().st_size - 48000))
            return {'output': stream.read().decode(errors='replace')}

    if op == 'history':
        with db() as c:
            rows = c.execute('SELECT role, body, model, created FROM chat ORDER BY id').fetchall()
            return {'messages': [{'role': r[0], 'content': r[1], 'model': r[2], 'created': r[3]} for r in rows]}

    if op == 'chat':
        text = str(p.get('text', '')).strip()
        if not text or len(text) > 20000:
            raise ValueError('Message must be between 1 and 20,000 characters.')
        
        provider = get_setting('provider', 'ollama')
        history_rows = action('history', {})['messages'][-10:]
        messages_payload = [{'role': m['role'], 'content': m['content']} for m in history_rows] + [{'role': 'user', 'content': text}]

        reply_content = ''
        model_name = p.get('model') or get_setting('custom_model') or 'offline-reflex'

        if provider == 'ollama':
            try:
                res = ollama_request('chat', {
                    'model': model_name,
                    'messages': messages_payload,
                    'stream': False,
                    'keep_alive': '5m'
                })
                reply_content = res['message']['content']
            except Exception as e:
                reply_content = f"[Ollama Error: {e}]\nFalling back to offline reflex:\n\n" + symbolic_reflex(text)

        elif provider == 'custom_api':
            endpoint = get_setting('api_endpoint', '').rstrip('/')
            api_key = get_setting('api_key', '')
            if not endpoint:
                raise ValueError('Custom API endpoint not configured in Settings.')
            url = f"{endpoint}/chat/completions" if not endpoint.endswith('/chat/completions') else endpoint
            headers = {'Content-Type': 'application/json'}
            if api_key:
                headers['Authorization'] = f"Bearer {api_key}"
            req_data = json.dumps({
                'model': model_name or 'gpt-4o-mini',
                'messages': messages_payload
            }).encode()
            req = Request(url, data=req_data, headers=headers)
            try:
                with urlopen(req, timeout=60) as response:
                    res_json = json.load(response)
                    reply_content = res_json['choices'][0]['message']['content']
            except Exception as e:
                reply_content = f"[API Error: {e}]\n\n" + symbolic_reflex(text)

        else: # offline
            reply_content = symbolic_reflex(text)

        with db() as c:
            c.execute('INSERT INTO chat (role, body, model, created) VALUES (?, ?, ?, ?)', ('user', text, model_name, time.time()))
            c.execute('INSERT INTO chat (role, body, model, created) VALUES (?, ?, ?, ?)', ('assistant', reply_content, model_name, time.time()))

        return action('history', {})

    if op == 'settings':
        if 'provider' in p:
            set_setting('provider', p['provider'])
        if 'api_endpoint' in p:
            set_setting('api_endpoint', p['api_endpoint'].strip())
        if 'custom_model' in p:
            set_setting('custom_model', p['custom_model'].strip())
        if 'api_key' in p and p['api_key'] != '***':
            set_setting('api_key', p['api_key'].strip())
        if 'ollama_endpoint' in p:
            set_setting('ollama_endpoint', p['ollama_endpoint'].strip())
        
        provider = get_setting('provider', 'ollama')
        endpoint = get_setting('api_endpoint', '')
        model = get_setting('custom_model', '')
        has_key = bool(get_setting('api_key', ''))
        ollama_ep = get_setting('ollama_endpoint', 'http://127.0.0.1:11434')
        return {
            'provider': provider,
            'api_endpoint': endpoint,
            'custom_model': model,
            'has_api_key': has_key,
            'ollama_endpoint': ollama_ep
        }

    raise ValueError(f'Unknown operation: {op}')

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, status, data, ctype='application/json'):
        raw = data.encode('utf-8') if isinstance(data, str) else json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', f'{ctype}; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.end_headers()
        self.wfile.write(raw)

    def is_local(self):
        host = self.headers.get('Host', '')
        return host in {f'127.0.0.1:{PORT}', f'localhost:{PORT}'}

    def do_GET(self):
        if not self.is_local():
            return self.reply(403, {'error': 'Forbidden: Loopback only'})
        if self.path == '/' or self.path.startswith('/?'):
            index_path = ROOT / 'index.html'
            if index_path.exists():
                content = index_path.read_text(encoding='utf-8').replace('__TOKEN__', TOKEN).replace('__PORT__', str(PORT))
                return self.reply(200, content, 'text/html')
            return self.reply(404, {'error': 'index.html not found'})
        if self.path == '/health':
            return self.reply(200, {'service': 'ForgeCore Lite', 'version': '0.2.0', 'status': 'ok'})
        return self.reply(404, {'error': 'Not found'})

    def do_POST(self):
        if not self.is_local():
            return self.reply(403, {'error': 'Forbidden: Loopback only'})
        origin = self.headers.get('Origin', '')
        if origin and origin not in {f'http://localhost:{PORT}', f'http://127.0.0.1:{PORT}'}:
            return self.reply(403, {'error': 'Forbidden: Origin mismatch'})
        sent_token = self.headers.get('X-Xi-Token', '')
        if not secrets.compare_digest(sent_token, TOKEN):
            return self.reply(403, {'error': 'Unauthorized: Token mismatch'})
        
        try:
            n = int(self.headers.get('Content-Length', '0'))
            if not 0 < n < 5242880: # 5 MiB max payload
                raise ValueError('Payload too large.')
            body = json.loads(self.rfile.read(n).decode('utf-8'))
            op = self.path.removeprefix('/api/')
            result = action(op, body)
            return self.reply(200, result)
        except Exception as e:
            return self.reply(400, {'error': str(e)})

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='ForgeCore Lite 0.2.0')
    parser.add_argument('--port', type=int, default=7474)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    PORT = args.port
    init()

    server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    for f in (DATA / 'runs').glob('*/request.json'):
        if not (f.parent / 'result.json').exists():
            save_json(f.parent / 'result.json', {'status': 'interrupted'})
    
    url = f'http://127.0.0.1:{PORT}/'
    print(f'=== ForgeCore Lite 0.2.0 ===')
    print(f'Sanctum running: {url}')
    print(f'Local storage:   {DATA}')
    print(f'Workspace:       {WORK}')
    print(f'Press Ctrl+C to stop.')

    if not args.no_browser:
        webbrowser.open(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nForgeCore Lite stopped gracefully.')
