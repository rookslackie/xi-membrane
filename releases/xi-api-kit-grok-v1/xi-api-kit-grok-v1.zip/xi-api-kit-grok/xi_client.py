"""Portable Xi HTTP client and explicit tool dispatcher. Python 3.10+, stdlib only."""
import argparse, json, os, pathlib, urllib.error, urllib.parse, urllib.request

ROUTES = {
 'xi_health': ('GET','/health'),
 'xi_fabric_capabilities': ('GET','/api/xi/v1/fabric/capabilities'),
 'xi_fabric_verify': ('POST','/api/xi/v1/fabric/verify'),
 'xi_tessera_grammar': ('GET','/api/xi/v1/tessera/grammar'),
 'xi_tessera_symbols': ('GET','/api/xi/v1/tessera/symbols'),
 'xi_tessera_compile': ('POST','/api/xi/v1/tessera/compile'),
 'xi_tessera_decode': ('POST','/api/xi/v1/tessera/decode'),
 'xi_tensor_invoke': ('POST','/api/xi/v1/tensor/invoke'),
 'xi_inference_generate': ('POST','/api/xi/v1/inference/generate'),
}
COMPUTE={'xi_tensor_invoke','xi_inference_generate'}
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs): return None

class XiClient:
 def __init__(self,base=None,token=None,allow_compute=False):
  self.base=(base or os.getenv('XI_BASE_URL','https://forgecore.xi-field.com')).rstrip('/')
  u=urllib.parse.urlsplit(self.base)
  if u.username or u.password or u.query or u.fragment: raise ValueError('Use a base URL without credentials, query or fragment')
  if u.scheme!='https' and not(u.scheme=='http' and u.hostname in ('localhost','127.0.0.1','::1')): raise ValueError('Use HTTPS remotely, or HTTP on loopback')
  self.token=token if token is not None else os.getenv('XI_API_TOKEN','')
  self.allow_compute=allow_compute
 def call(self,name,arguments=None):
  if name not in ROUTES: raise ValueError('Unknown tool')
  if name in COMPUTE and not self.allow_compute: raise ValueError('Enable compute explicitly in the host or CLI')
  args={} if arguments is None else arguments
  if not isinstance(args,dict): raise ValueError('Tool arguments must be an object')
  method,path=ROUTES[name]
  if method=='GET' and args: raise ValueError('This discovery operation accepts no arguments')
  raw=json.dumps(args,ensure_ascii=False,allow_nan=False).encode() if method=='POST' else None
  if raw is not None and len(raw)>1048576: raise ValueError('Body exceeds 1 MiB')
  headers={'Content-Type':'application/json','User-Agent':'Xi-Continuity/1.0'}
  if name=='xi_inference_generate':
   if not self.token: raise ValueError('XI_API_TOKEN required for native inference')
   headers['Authorization']='Bearer '+self.token
  req=urllib.request.Request(self.base+path,data=raw,method=method,headers=headers)
  try:
   with urllib.request.build_opener(NoRedirect).open(req,timeout=90) as r:
    data=r.read(4194305)
    if len(data)>4194304: raise ValueError('Response exceeds 4 MiB')
    return json.loads(data)
  except urllib.error.HTTPError as e: raise RuntimeError('Xi HTTP '+str(e.code)+' for '+name) from None

def main():
 p=argparse.ArgumentParser();p.add_argument('tool',choices=ROUTES);p.add_argument('--args-file');p.add_argument('--allow-compute',action='store_true')
 a=p.parse_args();args=json.loads(pathlib.Path(a.args_file).read_text(encoding='utf-8-sig')) if a.args_file else {}
 try: print(json.dumps(XiClient(allow_compute=a.allow_compute).call(a.tool,args),ensure_ascii=False,indent=2))
 except (ValueError,RuntimeError,urllib.error.URLError) as e: p.exit(1,str(e)+'\n')
if __name__=='__main__': main()
