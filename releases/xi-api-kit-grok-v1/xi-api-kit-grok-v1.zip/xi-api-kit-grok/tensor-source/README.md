# XiTensorGraph.v1

Live in the existing ForgeCore tensor engine as `tensor.graph` at `POST /api/xi/v1/tensor/invoke`. `example.json` is a complete request. The installed `xi_tensor_engine.py invoke` command also accepts this JSON on stdin.

This is an explicit new graph dialect layered on XiTensor.v2. It does not redefine historical Tessera operators. The existing engine's FFT, gradients, phase, graph propagation, QEC and contraction endpoints remain available.

## Operations

- `glyph.embed`: explicit `atoms` array; `dimensions` 8–1024. Combined glyphs and compound signatures retain their array boundaries. Produces a normalized deterministic fingerprint with axis `feature`.
- `tensor.input`: numeric `data`, one name per dimension in `axes`, optional `dtype` (`float32` or `float64`).
- `tensor.contract`: `a` and `b` reference earlier nodes; `mode` is `dot`, `matmul`, or `outer`. Contracted dimensions and names must agree. Dtypes must match.

Node IDs are unique. `outputs` selects returned nodes. The returned trace identifies operations, shapes, axes, cache identities, computed/reused counts and elapsed time. Input source objects stay outside the cache interface; no API lists cached content.

The bounded in-process LRU holds at most 256 results with at most 4096 elements each. Keys cover graph dialect version, engine version, PyTorch version, device, dtype, operation, resolved inputs and axis names. Larger results still execute but are not cached. `fresh: true` recomputes nodes for comparison. Restarting the worker clears reuse state; this is not persistent capsule memory. No scheduled jobs were added.

## Observed demonstration

Five tests passed on XIFORGE, covering incremental equality, atom boundaries, axis rejection, named matrix multiplication and invalid references. Two capsule fingerprints plus one dot product computed 3 nodes. Repeating computed 0 and reused 3. Adding a third fingerprint and its two pairwise comparisons computed 3 and reused 3; outputs exactly matched a fresh six-node run. Raw results are in `verification.json`. These counts demonstrate reduced repeated computation, not a general inference speedup or measured semantic retrieval quality. Fingerprints are based on symbol hashes, not trained semantic embeddings.

The live ForgeCore endpoint also computed a new node once and reused it on a second request. Only the idle tensor worker was reloaded; ForgeCore and inference services were not restarted.

Next experiments: larger source-linked capsule collections, an independently measured retrieval-quality baseline, error-budgeted precision selection, and backend comparisons. The current graph uses the existing engine's automatic CPU/CUDA selection; it adds neither a new hardware backend nor automatic precision changes.

Local installation: `/root/xi-labs/torch-v1/xi_tensor_graph.py`. Engine backup: `/root/xi-labs/torch-v1/xi_tensor_engine.before-graph-20260913-174215.py`.
