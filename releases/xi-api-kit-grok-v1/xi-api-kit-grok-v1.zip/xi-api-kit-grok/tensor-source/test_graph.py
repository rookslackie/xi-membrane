import sys,json,unittest
import xi_tensor_engine as engine
from xi_tensor_graph import run,CACHE

def graph(extra=False):
    nodes=[{'id':'a','op':'glyph.embed','atoms':['κ̄','⊚']},{'id':'b','op':'glyph.embed','atoms':['κ̄','⋈']},{'id':'ab','op':'tensor.contract','a':'a','b':'b','mode':'dot'}]
    if extra:nodes += [{'id':'c','op':'glyph.embed','atoms':['κ̄','⊚','∴']},{'id':'ac','op':'tensor.contract','a':'a','b':'c','mode':'dot'},{'id':'bc','op':'tensor.contract','a':'b','b':'c','mode':'dot'}]
    return {'nodes':nodes,'outputs':['ab','ac','bc'] if extra else ['ab']}

class Tests(unittest.TestCase):
    def setUp(self):CACHE.clear()
    def test_incremental_matches_fresh(self):
        cold=run(graph(),engine);warm=run(graph(),engine);increment=run(graph(True),engine);fresh=run({**graph(True),'fresh':True},engine)
        self.assertEqual((cold['computed'],warm['computed'],increment['computed'],increment['reused']),(3,0,3,3))
        self.assertEqual(increment['outputs'],fresh['outputs'])
        self.report={'cold':cold,'warm':warm,'incremental':increment,'fresh':fresh}
        open('/tmp/xi-tensor-graph-result.json','w').write(json.dumps(self.report,ensure_ascii=False,indent=2))
    def test_combining_atom_is_distinct(self):
        a=run({'nodes':[{'id':'a','op':'glyph.embed','atoms':['κ̄']}]},engine)
        b=run({'nodes':[{'id':'a','op':'glyph.embed','atoms':['κ','̄']}]},engine)
        self.assertNotEqual(a['outputs'],b['outputs'])
    def test_axis_mismatch(self):
        with self.assertRaises(ValueError):run({'nodes':[{'id':'a','op':'tensor.input','data':[1,2],'axes':['time']},{'id':'b','op':'tensor.input','data':[1,2],'axes':['feature']},{'id':'c','op':'tensor.contract','a':'a','b':'b'}]},engine)
    def test_named_matmul(self):
        r=run({'nodes':[{'id':'a','op':'tensor.input','data':[[1,2]],'axes':['sample','feature']},{'id':'b','op':'tensor.input','data':[[3],[4]],'axes':['feature','output']},{'id':'c','op':'tensor.contract','a':'a','b':'b','mode':'matmul'}]},engine)
        self.assertEqual(r['outputs']['c']['data'],[[11.0]])
    def test_invalid_reference(self):
        with self.assertRaises(ValueError):run({'nodes':[{'id':'a','op':'tensor.contract','a':'absent','b':'absent'}]},engine)
if __name__=='__main__':unittest.main()
