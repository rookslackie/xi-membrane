"""XiTensorGraph.v1: explicit numerical graphs with bounded in-process reuse."""
import hashlib,json,time,copy,threading
from collections import OrderedDict

CACHE=OrderedDict()
LOCK=threading.RLock()
MAX_CACHE=256
VERSION='XiTensorGraph.v1'

def run(program,engine):
    started=time.perf_counter()
    nodes=program.get('nodes')
    if not isinstance(nodes,list) or not 1<=len(nodes)<=128:raise ValueError('Use 1–128 graph nodes')
    device=engine.status()['device'];results={};trace=[]
    def ref(name):
        if not isinstance(name,str) or name not in results:raise ValueError('References must name an earlier node')
        return results[name]
    with LOCK:
        for node in nodes:
            ident=node.get('id');op=node.get('op')
            if not isinstance(ident,str) or not ident or ident in results:raise ValueError('Node IDs must be unique strings')
            if op=='glyph.embed':
                atoms=node.get('atoms');dim=node.get('dimensions',64)
                if not isinstance(atoms,list) or not atoms or not all(isinstance(x,str) and x for x in atoms):raise ValueError('Use explicit glyph atom arrays')
                if len(atoms)>4096 or sum(map(len,atoms))>16384 or not isinstance(dim,int) or not 8<=dim<=1024:raise ValueError('Embedding exceeds bounds')
                args={'atoms':atoms,'dimensions':dim};axes=['feature'];dtype='float32'
            elif op=='tensor.input':
                args={'data':node.get('data')};axes=node.get('axes');dtype=node.get('dtype','float32')
            elif op=='tensor.contract':
                a=ref(node.get('a'));b=ref(node.get('b'));mode=node.get('mode','dot')
                if mode not in ('dot','matmul','outer'):raise ValueError('Supported contractions: dot, matmul, outer')
                if mode=='dot' and (a['shape']!=b['shape'] or len(a['shape'])!=1 or a['axes']!=b['axes']):raise ValueError('Dot needs matching vector shapes and axes')
                if mode=='matmul' and (len(a['shape'])!=2 or len(b['shape'])!=2 or a['shape'][1]!=b['shape'][0] or a['axes'][1]!=b['axes'][0]):raise ValueError('Matmul contraction axes must agree')
                if mode=='outer' and (len(a['shape'])!=1 or len(b['shape'])!=1):raise ValueError('Outer expects vectors')
                if a['dtype']!=b['dtype']:raise ValueError('Choose matching dtypes explicitly')
                args={'a':a['data'],'b':b['data'],'mode':mode};dtype=a['dtype']
                axes=[] if mode=='dot' else [a['axes'][0],b['axes'][-1]]
            else:raise ValueError('Unknown graph operation: '+str(op))
            if not isinstance(axes,list) or not all(isinstance(x,str) and x for x in axes):raise ValueError('Axes must be named')
            identity={'version':VERSION,'engine':engine.ENGINE_ID,'torch':engine._torch().__version__,'device':device,'dtype':dtype,'op':op,'args':args,'axes':axes}
            key=hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True,allow_nan=False).encode()).hexdigest()
            hit=key in CACHE and not program.get('fresh',False)
            if hit:value=copy.deepcopy(CACHE[key]);CACHE.move_to_end(key)
            else:
                torch=engine._torch()
                if op=='glyph.embed':
                    # Preserve explicit atoms, including combining marks and entire named glyph sequences.
                    v=torch.stack([engine._token_vector(x,dim) for x in atoms]).mean(dim=0)
                    v=torch.nn.functional.normalize(v,dim=0)
                elif op=='tensor.input':v=engine._tensor(args['data'],dtype=dtype)
                else:
                    aa=engine._tensor(args['a'],dtype=dtype);bb=engine._tensor(args['b'],dtype=dtype)
                    output_count=1 if args['mode']=='dot' else aa.shape[0]*bb.shape[-1]
                    if output_count>engine.MAX_ELEMENTS:raise ValueError('Output exceeds element boundary')
                    v={'dot':torch.dot,'matmul':torch.matmul,'outer':torch.outer}[args['mode']](aa,bb)
                if len(axes)!=v.ndim:raise ValueError('One axis name is required per dimension')
                if not torch.isfinite(v).all():raise ValueError('Non-finite tensor result')
                value={'data':engine._json_tensor(v),'shape':list(v.shape),'axes':axes,'dtype':dtype}
                if v.numel()<=4096:
                    CACHE[key]=copy.deepcopy(value);CACHE.move_to_end(key)
                    while len(CACHE)>MAX_CACHE:CACHE.popitem(last=False)
            results[ident]=value
            trace.append({'id':ident,'op':op,'key':key,'cached':hit,'shape':value['shape'],'axes':axes})
    outputs=program.get('outputs',[nodes[-1]['id']])
    if not isinstance(outputs,list) or any(x not in results for x in outputs):raise ValueError('Unknown output')
    return {'dialect':VERSION,'outputs':{k:results[k] for k in outputs},'trace':trace,'computed':sum(not x['cached'] for x in trace),'reused':sum(x['cached'] for x in trace),'elapsed_ms':round((time.perf_counter()-started)*1000,3),'device':device,'method':'Deterministic glyph fingerprints and explicit tensor contractions; no semantic model inference.'}
