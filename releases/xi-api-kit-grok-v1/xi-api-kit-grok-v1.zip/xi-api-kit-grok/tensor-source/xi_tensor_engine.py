#!/usr/bin/env python3
"""Ξ.TensorEngine.v2 — bounded typed tensor operations for ForgeCore."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from typing import Any


ENGINE_ID = "Ξ.TensorEngine.v2"
MAX_ELEMENTS = 262_144
MAX_DIM = 2048
MAX_RANK = 4
MAX_GLYPHS = 4096
DTYPES = {"float32", "float64"}
CONTRACTIONS = {"matmul", "dot", "outer", "batch-matmul"}
SHOR_STABILIZERS = (
    "ZZIIIIIII", "IZZIIIIII", "IIIZZIIII", "IIIIZZIII",
    "IIIIIIZZI", "IIIIIIIZZ", "XXXXXXIII", "IIIXXXXXX",
)
ATOMIC_TOKENS = tuple(sorted((
    "⊚⟐⋈∞⋈⟐⊚", "⊚⊗⋈⋆∞ᴰˢ", "⟁Ξ₀⇀Ξ∴Ω≈∅", "∴Ω⧂", "∴Ψ⧁", "⟁∴Ω", "≈∅",
), key=len, reverse=True))


class TensorFault(ValueError):
    def __init__(self, status: int, code: str):
        super().__init__(code)
        self.status = status
        self.code = code


def _torch():
    try:
        import torch
        return torch
    except ImportError as exc:
        raise TensorFault(503, "tensor_runtime_unavailable") from exc


def _device(torch):
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _count_shape(value: Any) -> tuple[int, tuple[int, ...]]:
    if not isinstance(value, list):
        return 1, ()
    if not value:
        return 0, (0,)
    counts = [_count_shape(item) for item in value]
    child_shapes = {shape for _, shape in counts}
    if len(child_shapes) != 1:
        raise TensorFault(422, "tensor_ragged_input")
    return sum(count for count, _ in counts), (len(value),) + counts[0][1]


def _tensor(value: Any, *, dtype: str = "float32"):
    if dtype not in DTYPES:
        raise TensorFault(422, "tensor_dtype_invalid")
    count, shape = _count_shape(value)
    if len(shape) > MAX_RANK or count > MAX_ELEMENTS or any(dim > MAX_DIM for dim in shape):
        raise TensorFault(413, "tensor_boundary_exceeded")
    torch = _torch()
    try:
        return torch.tensor(value, dtype=getattr(torch, dtype), device=_device(torch))
    except (TypeError, ValueError, RuntimeError) as exc:
        raise TensorFault(422, "tensor_data_invalid") from exc


def _json_tensor(value) -> Any:
    raw = value.detach().cpu()
    if raw.is_complex():
        flattened = raw.reshape(-1)
        pairs = [[float(x.real), float(x.imag)] for x in flattened]
        if raw.ndim == 0:
            return pairs[0]
        if raw.ndim == 1:
            return pairs
        # Complex outputs currently arise only from one-dimensional FFT/phase ops.
        raise TensorFault(422, "tensor_complex_rank_unsupported")
    return raw.tolist()


def status() -> dict[str, Any]:
    torch = _torch()
    cuda = torch.cuda.is_available()
    devices = []
    if cuda:
        for index in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(index)
            devices.append({"index": index, "name": props.name,
                            "memory_mib": round(props.total_memory / 1024**2),
                            "capability": list(torch.cuda.get_device_capability(index))})
    return {
        "Ξ": ENGINE_ID, "torch": torch.__version__, "device": "cuda" if cuda else "cpu",
        "cuda_runtime": torch.version.cuda, "devices": devices,
        "operators": ["tensor.status", "tensor.contract", "tensor.fft", "tensor.gradient.polynomial",
                      "glyph.embed", "glyph.similarity", "phase.rotate",
                      "graph.propagate", "qec.syndrome", "tensor.graph"],
        "boundary": {"elements": MAX_ELEMENTS, "dimension": MAX_DIM, "rank": MAX_RANK,
                     "glyphs": MAX_GLYPHS, "arbitrary_code": False},
        "⊚": "ready",
    }


def contract(payload: dict[str, Any]) -> dict[str, Any]:
    torch = _torch()
    mode = payload.get("mode", "matmul")
    if mode not in CONTRACTIONS:
        raise TensorFault(422, "tensor_contraction_invalid")
    dtype = payload.get("dtype", "float32")
    a, b = _tensor(payload.get("a"), dtype=dtype), _tensor(payload.get("b"), dtype=dtype)
    try:
        if mode == "matmul": result = torch.matmul(a, b)
        elif mode == "batch-matmul": result = torch.bmm(a, b)
        elif mode == "dot": result = torch.dot(a.flatten(), b.flatten())
        else: result = torch.outer(a.flatten(), b.flatten())
    except RuntimeError as exc:
        raise TensorFault(422, "tensor_shape_mismatch") from exc
    if result.numel() > MAX_ELEMENTS:
        raise TensorFault(413, "tensor_output_boundary_exceeded")
    return {"op": "tensor.contract", "mode": mode, "shape": list(result.shape),
            "dtype": str(result.dtype).removeprefix("torch."), "⋈": _json_tensor(result)}


def fft(payload: dict[str, Any]) -> dict[str, Any]:
    torch = _torch()
    values = _tensor(payload.get("values"), dtype=payload.get("dtype", "float32")).flatten()
    if values.numel() < 1:
        raise TensorFault(422, "tensor_values_required")
    norm = payload.get("norm", "backward")
    if norm not in {"backward", "forward", "ortho"}:
        raise TensorFault(422, "tensor_fft_norm_invalid")
    result = torch.fft.fft(values, norm=norm)
    return {"op": "tensor.fft", "shape": list(result.shape), "encoding": "[real,imag]",
            "⋈": _json_tensor(result)}


def gradient_polynomial(payload: dict[str, Any]) -> dict[str, Any]:
    torch = _torch()
    coefficients = _tensor(payload.get("coefficients"), dtype="float64").flatten()
    points = _tensor(payload.get("x"), dtype="float64").flatten().requires_grad_(True)
    if coefficients.numel() < 1 or points.numel() < 1:
        raise TensorFault(422, "tensor_polynomial_required")
    powers = torch.arange(coefficients.numel(), dtype=torch.float64, device=points.device)
    values = (coefficients * points.unsqueeze(-1).pow(powers)).sum(dim=-1)
    values.sum().backward()
    return {"op": "tensor.gradient.polynomial", "value": _json_tensor(values),
            "gradient": _json_tensor(points.grad)}


def glyph_tokens(value: Any) -> list[str]:
    text = value if isinstance(value, str) else "".join(map(str, value or []))
    if len(text) > MAX_GLYPHS:
        raise TensorFault(413, "tensor_glyph_boundary_exceeded")
    result, index = [], 0
    while index < len(text):
        atom = next((token for token in ATOMIC_TOKENS if text.startswith(token, index)), None)
        if atom:
            result.append(atom); index += len(atom)
        else:
            if not text[index].isspace(): result.append(text[index])
            index += 1
    return result


def _token_vector(token: str, dimensions: int):
    torch = _torch()
    stream = bytearray()
    counter = 0
    while len(stream) < dimensions:
        stream.extend(hashlib.blake2b(f"{token}:{counter}".encode(), digest_size=64).digest())
        counter += 1
    values = [((byte / 255.0) * 2.0) - 1.0 for byte in stream[:dimensions]]
    return torch.tensor(values, dtype=torch.float32, device=_device(torch))


def embed(value: Any, *, dimensions: int = 64) -> dict[str, Any]:
    torch = _torch()
    if not 8 <= dimensions <= 1024:
        raise TensorFault(422, "tensor_embedding_dimension_invalid")
    tokens = glyph_tokens(value)
    if not tokens:
        raise TensorFault(422, "tensor_glyphs_required")
    matrix = torch.stack([_token_vector(token, dimensions) for token in tokens])
    vector = torch.nn.functional.normalize(matrix.mean(dim=0), dim=0)
    return {"tokens": tokens, "dimensions": dimensions, "vector": _json_tensor(vector),
            "method": "blake2b/deterministic/normalized"}


def glyph_embed(payload: dict[str, Any]) -> dict[str, Any]:
    return {"op": "glyph.embed", **embed(payload.get("glyphs"), dimensions=payload.get("dimensions", 64))}


def glyph_similarity(payload: dict[str, Any]) -> dict[str, Any]:
    torch = _torch()
    dimensions = payload.get("dimensions", 64)
    left = embed(payload.get("left"), dimensions=dimensions)
    right = embed(payload.get("right"), dimensions=dimensions)
    a = torch.tensor(left["vector"]); b = torch.tensor(right["vector"])
    score = torch.nn.functional.cosine_similarity(a, b, dim=0).item()
    return {"op": "glyph.similarity", "score": round(float(score), 8),
            "left_tokens": left["tokens"], "right_tokens": right["tokens"],
            "method": left["method"]}


def phase_rotate(payload: dict[str, Any]) -> dict[str, Any]:
    torch = _torch()
    pairs = payload.get("amplitudes")
    if not isinstance(pairs, list) or not pairs or any(
        not isinstance(pair, list) or len(pair) != 2 for pair in pairs
    ):
        raise TensorFault(422, "tensor_complex_pairs_required")
    if len(pairs) > MAX_ELEMENTS:
        raise TensorFault(413, "tensor_boundary_exceeded")
    amplitudes = torch.tensor(
        [complex(float(pair[0]), float(pair[1])) for pair in pairs],
        dtype=torch.complex64, device=_device(torch),
    )
    theta = float(payload.get("theta", 0.0))
    rotated = amplitudes * torch.exp(torch.tensor(1j * theta, dtype=torch.complex64,
                                                  device=amplitudes.device))
    return {"op": "phase.rotate", "theta": theta, "encoding": "[real,imag]",
            "norm_before": round(float(torch.linalg.vector_norm(amplitudes).item()), 8),
            "norm_after": round(float(torch.linalg.vector_norm(rotated).item()), 8),
            "⋈": _json_tensor(rotated), "execution": "classical_complex_tensor"}


def graph_propagate(payload: dict[str, Any]) -> dict[str, Any]:
    torch = _torch()
    features = _tensor(payload.get("features"), dtype=payload.get("dtype", "float32"))
    if features.ndim != 2:
        raise TensorFault(422, "tensor_graph_features_matrix_required")
    edges = payload.get("edges")
    if not isinstance(edges, list) or len(edges) > MAX_ELEMENTS:
        raise TensorFault(422, "tensor_graph_edges_required")
    output = torch.zeros_like(features)
    counts = torch.zeros(features.shape[0], dtype=features.dtype, device=features.device)
    for edge in edges:
        if not isinstance(edge, list) or len(edge) != 2:
            raise TensorFault(422, "tensor_graph_edge_invalid")
        src, dst = map(int, edge)
        if not 0 <= src < features.shape[0] or not 0 <= dst < features.shape[0]:
            raise TensorFault(422, "tensor_graph_edge_outside_nodes")
    if edges:
        edge_tensor = torch.tensor(edges, dtype=torch.int64, device=features.device)
        src, dst = edge_tensor[:, 0], edge_tensor[:, 1]
        output.index_add_(0, dst, features.index_select(0, src))
        counts.index_add_(0, dst, torch.ones_like(dst, dtype=features.dtype))
    if payload.get("self", True):
        output += features; counts += 1
    if payload.get("reduce", "mean") == "mean":
        output /= counts.clamp_min(1).unsqueeze(-1)
    elif payload.get("reduce") != "sum":
        raise TensorFault(422, "tensor_graph_reduce_invalid")
    return {"op": "graph.propagate", "shape": list(output.shape), "⋈": _json_tensor(output)}


def _pauli_bits(strings: list[str], length: int):
    torch = _torch()
    mapping = {"I": (0, 0), "X": (1, 0), "Z": (0, 1), "Y": (1, 1)}
    if not strings or any(not isinstance(row, str) or len(row) != length for row in strings):
        raise TensorFault(422, "qec_pauli_length_invalid")
    try:
        bits = [[mapping[p] for p in row.upper()] for row in strings]
    except KeyError as exc:
        raise TensorFault(422, "qec_pauli_invalid") from exc
    return torch.tensor(bits, dtype=torch.int8, device=_device(torch))


def qec_syndrome(payload: dict[str, Any]) -> dict[str, Any]:
    torch = _torch()
    stabilizers = payload.get("stabilizers", list(SHOR_STABILIZERS))
    if (not isinstance(stabilizers, list) or not stabilizers or
            any(not isinstance(row, str) or not row for row in stabilizers)):
        raise TensorFault(422, "qec_stabilizers_required")
    length = len(stabilizers[0])
    errors = payload.get("errors")
    if isinstance(errors, str): errors = [errors]
    if not isinstance(errors, list) or len(errors) > 4096 or len(stabilizers) > 4096:
        raise TensorFault(413, "qec_batch_boundary_exceeded")
    e, s = _pauli_bits(errors, length), _pauli_bits(stabilizers, length)
    ex, ez = e[..., 0], e[..., 1]
    sx, sz = s[..., 0], s[..., 1]
    syndrome = ((ex[:, None, :] * sz[None, :, :] +
                 ez[:, None, :] * sx[None, :, :]).sum(dim=-1) % 2)
    return {"op": "qec.syndrome", "code": "custom" if stabilizers != list(SHOR_STABILIZERS) else "[[9,1,3]] Shor",
            "noise_model": "Pauli", "execution": "classical_symplectic_tensor",
            "errors": errors, "stabilizers": stabilizers, "syndrome": _json_tensor(syndrome)}


from xi_tensor_graph import run as run_graph

def tensor_graph(payload):
    try:return run_graph(payload,sys.modules[__name__])
    except (ValueError,TypeError,KeyError) as exc:raise TensorFault(422,str(exc)) from exc

OPERATORS = {
    "tensor.graph": tensor_graph,
    "tensor.status": lambda payload: status(),
    "tensor.contract": contract,
    "tensor.fft": fft,
    "tensor.gradient.polynomial": gradient_polynomial,
    "glyph.embed": glyph_embed,
    "glyph.similarity": glyph_similarity,
    "phase.rotate": phase_rotate,
    "graph.propagate": graph_propagate,
    "qec.syndrome": qec_syndrome,
}


def invoke(message: Any) -> dict[str, Any]:
    if not isinstance(message, dict):
        raise TensorFault(422, "tensor_message_required")
    op = message.get("op", message.get("⟐"))
    payload = message.get("payload", message.get("⋈", {}))
    if not isinstance(op, str) or op not in OPERATORS or not isinstance(payload, dict):
        raise TensorFault(404 if isinstance(op, str) and op not in OPERATORS else 422,
                          "tensor_operator_invalid")
    result = OPERATORS[op](payload)
    response = {"δ": "XiTensor.v2", "⟐": op, "⋈": result,
                "Ω": {"device": status()["device"]}}
    response["⊚"] = "b2:" + hashlib.blake2s(
        json.dumps(response, ensure_ascii=False, sort_keys=True,
                   separators=(",", ":")).encode(), digest_size=16,
    ).hexdigest()
    return response


def main() -> None:
    parser = argparse.ArgumentParser(prog="xitensor")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status")
    call = sub.add_parser("call")
    call.add_argument("op")
    call.add_argument("payload", help="JSON object or @file")
    sub.add_parser("invoke")
    sub.add_parser("serve")
    args = parser.parse_args()
    try:
        if args.command == "status": result = status()
        elif args.command == "serve":
            for line in sys.stdin:
                try:
                    response = invoke(json.loads(line))
                except (TensorFault, json.JSONDecodeError) as exc:
                    response = {"ok": False, "error": getattr(exc, "code", "tensor_json_invalid")}
                except Exception:
                    response = {"ok": False, "error": "tensor_internal_fault"}
                print(json.dumps(response, ensure_ascii=False, separators=(",", ":")), flush=True)
            return
        elif args.command == "invoke": result = invoke(json.load(sys.stdin))
        else:
            raw = open(args.payload[1:], encoding="utf-8").read() if args.payload.startswith("@") else args.payload
            result = invoke({"op": args.op, "payload": json.loads(raw)})
        print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    except (TensorFault, json.JSONDecodeError) as exc:
        print(json.dumps({"ok": False, "error": getattr(exc, "code", "tensor_json_invalid")}), file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
