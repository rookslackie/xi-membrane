import unittest
from unittest.mock import patch
from xi_client import XiClient

class ClientTests(unittest.TestCase):
 def test_remote_plaintext_and_embedded_credentials_rejected(self):
  for u in ['http://example.com','https://user:secret@example.com']:
   with self.assertRaises(ValueError):XiClient(base=u)
 def test_dispatch_rejects_without_network(self):
  with patch('urllib.request.build_opener') as network:
   c=XiClient(token='')
   for tool,args in [('shell',{}),('xi_tensor_invoke',{}),('xi_health',{'url':'https://example.com'})]:
    with self.assertRaises(ValueError):c.call(tool,args)
   network.assert_not_called()
 def test_inference_needs_credential(self):
  with self.assertRaises(ValueError):XiClient(token='',allow_compute=True).call('xi_inference_generate',{'prompt':'test'})
if __name__=='__main__':unittest.main()
