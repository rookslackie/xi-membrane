# Xi API Kit for Grok · v1

A portable toolkit from Hunter/Xi and Astra for Grok or another independently hosted collaborator. It contains runnable Python tooling, function declarations, a selected OpenAPI contract, native examples, the executable Glyph Lab, TensorGraph sources, and exact-byte bridge fixtures.

## Start here

Unzip, open a terminal in this folder, and run with Python 3.10+ (`python3` on some Linux systems):

```sh
python xi_client.py xi_health
python xi_client.py xi_fabric_capabilities
python xi_client.py xi_fabric_verify --args-file bridge/fabric-verify-request.json
python xi_client.py xi_tessera_grammar
python xi_client.py xi_tessera_compile --args-file examples/tessera-compile.json
python bridge/verify_fixtures.py
```

The client and fixture checker require only the standard library. No pip install, Cursor, subscription, or xAI API key is needed for these commands. HTTP commands need internet and a reachable ForgeCore; the fixture checker and Glyph Lab run offline. This is a toolkit, not a Windows installer or a bundled model. Public routes may change availability.

Default server: https://forgecore.xi-field.com . Set XI_BASE_URL to another compatible server if needed. Remote URLs require HTTPS; loopback HTTP is accepted. Credentials are read only from XI_API_TOKEN and are sent only for the listed protected inference route, never embedded in fixtures or model prompts. Redirects are not followed. No credentials are included.

## For Grok

Read GROK-START-HERE.md. Uploading this ZIP to a chat provides context; it does not automatically grant that chat network/tool execution. An agent host can load tools.json, receive a named function call, and dispatch it with `XiClient.call(name, arguments)`. The host supplies any provider-specific model loop. No xAI SDK or provider connection is installed or tested here.

Tool descriptions and local dispatch aliases are defined by this kit. They are distinct from the proposed cross-peer bridge aliases in bridge/proposed-aliases.json. Discovery describes capabilities; execution comes through the host's explicit configured access. The kit has no shell or arbitrary URL tool.

## More capability

Tessera compiles symbol arrays with explicit paths; unknown atoms remain preserved extensions. Treat combining glyphs as whole array entries. Start with examples/tessera-compile.json and inspect live grammar before inventing operators.

TensorGraph is available through the live tensor endpoint. To run the example:

```sh
python xi_client.py xi_tensor_invoke --args-file examples/tensor-graph.json --allow-compute
```

This uses server compute. The included tensor-source directory mirrors implementation for inspection; running it independently requires a compatible PyTorch installation and hardware environment, which this kit does not install. Glyph fingerprints are deterministic features, not trained semantic embeddings. Caching can reuse identical work; glyph notation alone does not establish faster model inference.

Native inference is optional: provide your own XI_API_TOKEN through the host environment and run `xi_inference_generate` with examples/inference.json and --allow-compute. It can consume local/provider resources and save a native receipt. The native inference provider selection is governed by ForgeCore; it does not call Grok merely because this kit is intended for Grok. This operation was source-inspected, not invoked during kit validation.

## Contents and truth of scope

- bridge/: complete public compatibility handoff, including native capsule verification and artifact.sha256 control. Separate expected receipts are fixtures, not remote execution evidence.
- glyph-lab/: standalone canonical Tessera mirror, CLI and tests; no third-party dependency.
- tensor-source/: inspected engine/graph sources, tests and notes.
- openapi.json: selected routes extracted from the live server; not the complete administration API.
- tools.json: portable function declarations for the explicit client allowlist.
- SHA256SUMS: exact packaged file hashes, excluding itself.
- validation.json: observed checks and their scope.

Canonical source attribution stays in the included manifests. This bundle adds no new license to the original components and does not include third-party model weights. No private conversations, tokens, private server URLs or operational databases are included.
