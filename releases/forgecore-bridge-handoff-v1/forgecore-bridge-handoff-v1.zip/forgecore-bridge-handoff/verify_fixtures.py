"""Verify exact fixture bytes and native capsule hashes; no services or packages needed."""
import base64, hashlib, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parent
def load(name): return json.loads((ROOT/name).read_text(encoding='utf-8'))
def canonical(obj): return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def sha(raw): return hashlib.sha256(raw).hexdigest()

raw=(ROOT/'legacy-exchange.json').read_bytes()
legacy=load('legacy-exchange.json')
integrity=legacy.pop('integrity')
assert sha(canonical(legacy)) == integrity['digest']
capsule=load('bridge-capsule.json')
content=capsule['content']
assert base64.b64decode(content['data'],validate=True) == raw
assert content['size_bytes'] == len(raw)
assert content['sha256'] == sha(raw)
fabric=load('fabric-capsule.json')
assert fabric['⟁'] == 'sha256:'+sha(canonical({'⋈':fabric['⋈'],'Ω':fabric['Ω']}))
closure=fabric.pop('⊚')
assert closure == 'b2:'+hashlib.blake2s(canonical(fabric),digest_size=16).hexdigest()
assert load('fabric-verify-result.json')['valid'] is True
request=load('bridge-request.json'); result=load('bridge-expected-result.json')
assert result['request_id'] == request['request_id'] == result['payload']['receipt']['request_id']
assert result['payload']['output']['sha256'] == sha(raw)
assert result['payload']['receipt']['artifact_sha256'] == sha(raw)
assert result['sender'] == request['recipient']
native=load('native-bridge-capsule.json')
nraw=base64.b64decode(native['content']['data'],validate=True)
assert nraw == (ROOT/'fabric-capsule.json').read_bytes()
assert sha(nraw) == native['content']['sha256']
assert len(nraw) == native['content']['size_bytes']
nreq=load('native-bridge-request.json'); nres=load('native-bridge-expected-result.json')
assert nreq['payload']['input']['capsule'] == json.loads(nraw)
assert nreq['payload']['capsule_id'] == native['capsule_id']
assert nreq['request_id'] == nres['request_id'] == nres['payload']['receipt']['request_id']
assert nres['payload']['output'] == load('fabric-verify-result.json')
assert nres['payload']['receipt']['artifact_sha256'] == sha(nraw)
assert load('native-bridge-expected-receipt.json') == nres['payload']['receipt']
assert load('bridge-expected-receipt.json') == result['payload']['receipt']
if (ROOT/'SHA256SUMS').exists():
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        assert sha((ROOT/name).read_bytes()) == digest, name
print('PASS: legacy integrity, byte-preserving bridge capsule, fabric address/closure, live verification, request/result binding.')
